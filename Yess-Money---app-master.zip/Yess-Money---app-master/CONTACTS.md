# 📞 Контакты Yess! Loyalty

## 👥 Команда проекта

### 🚀 Керимов Нарбото Канатбекович
- **Роль**: Фронтенд разработчик
- 📧 Email: narbotokerimov@gmail.com
- 📱 Телефон: +996 504 876 087
- 💬 Telegram: @He5oYaIVI

### 🎨 Жакиев Актан Дайырбекович
- **Роль**: Главный дизайнер
- 📧 Email: Jakievaktan@gmail.com
- 📱 Телефон: +996 995 191 949
- 💬 Telegram: @AktanJakiev

### 💻 Айтбеков Аманбол Айтбекович
- **Роль**: Backend разработчик
- 📧 Email: aman4ikaitbekov@icloud.com
- 📱 Телефон: +996 551 69 72 96
- 💬 Telegram: @amanch1ikk

## 🌐 Официальные каналы связи

- **Корпоративный Email**: support@yess-loyalty.com
- **Телефон поддержки**: +996 551 69 72 96
- **Адрес**: г. Бишкек, Кыргызстан

## 🤝 Социальные сети

- [LinkedIn](https://www.linkedin.com/company/yess-loyalty)
- [Facebook](https://www.facebook.com/yessloyalty)
- [Instagram](https://www.instagram.com/yess.loyalty)

## 💡 Для партнеров и инвесторов

- **Электронная почта**: partners@yess-loyalty.com
- **Телефон**: +996 551 69 72 96

---

**© 2025 Yess! Loyalty - Технологии с душой Кыргызстана** 🇰🇬
