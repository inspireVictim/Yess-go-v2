"""Pydantic schemas"""

